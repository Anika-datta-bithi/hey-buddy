import 'package:flutter/material.dart';

class Smalllipsvideo extends StatefulWidget {
  _WidgetState createState() => _WidgetState();
}

class _WidgetState extends State<Smalllipsvideo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Watch video tutorial'),
        backgroundColor: Colors.pink,
      ),
    );
  }
}
