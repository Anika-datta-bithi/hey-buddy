import 'package:flutter/material.dart';

class Lipsticks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: 200,
          ),
        ],
      ),
    ));
    Image.network('');
  }
}
